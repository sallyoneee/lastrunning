/// <reference types="vite/client" />

interface Window {
  Telegram?: {
    WebApp: any;
  };
}